#pragma once

#ifndef COUT_H
#define COUT_H

void StrToHex(BYTE *pbDest, BYTE *pbSrc, int nLen);
void HexToStr(BYTE *pbDest, BYTE *pbSrc, int nLen);

#endif



