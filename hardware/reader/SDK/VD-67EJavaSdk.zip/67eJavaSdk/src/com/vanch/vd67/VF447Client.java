package com.vanch.vd67;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class VF447Client {
    private PointerByReference handler;

    static {
        System.setProperty("jna.library.path", new File("libs").getAbsolutePath());
    }

    interface ReaderDynamicLib extends Library {
        VF447Client.ReaderDynamicLib INSTANCE = Native.load("ReaderDynamicLib", VF447Client.ReaderDynamicLib.class);

        int Net_ConnectScanner(PointerByReference hSocket, String nTargetAddress, short nTargetPort, String nHostAddress, short nHostPort);

        int Net_GetRelay(Pointer hSocket, IntByReference Relay);

        int Net_SetRelay(Pointer hSocket, int Relay);

        int Net_DisconnectScanner();

        int Net_EPC1G2_ReadLabelID(Pointer hSocket, byte mem, int ptr, byte len, byte[] mask, byte[] buff, IntByReference nCounter);
    }

    public static class RelayStatus {
        public boolean relay1;
        public boolean relay2;

        @Override
        public String toString() {
            return "RelayStatus{" +
                    "relay1=" + relay1 +
                    ", relay2=" + relay2 +
                    '}';
        }
    }

    public int Net_ConnectScanner(String nTargetAddress, short nTargetPort, String nHostAddress, short nHostPort) {
        PointerByReference handler = new PointerByReference();
        int ret = ReaderDynamicLib.INSTANCE.Net_ConnectScanner(handler, nTargetAddress, nTargetPort, nHostAddress, nHostPort);
        this.handler = handler;
        return ret;
    }

    public RelayStatus Net_getRelayStatus() {

        IntByReference relay = new IntByReference();
        int ret = ReaderDynamicLib.INSTANCE.Net_GetRelay(handler.getValue(), relay);
        if (ret == 0) {
            int status = relay.getValue();
            RelayStatus relayStatus = new RelayStatus();
            relayStatus.relay1 = (status & 0x01) == 0x01;
            relayStatus.relay2 = (status & 0x02) == 0x02;
            return relayStatus;
        }
        return null;
    }

    public int Net_setRelayStatus(RelayStatus status) {
        int _status = 0;
        if (status.relay1) _status += 0x01;
        if (status.relay2) _status += 0x02;

        return ReaderDynamicLib.INSTANCE.Net_SetRelay(handler.getValue(), _status);
    }

    public int Net_Disconnect() {
        return ReaderDynamicLib.INSTANCE.Net_DisconnectScanner();
    }

    public byte[] readEPC() {
        IntByReference count = new IntByReference();
        byte[] buff = new byte[30 * 256];
        int ret = ReaderDynamicLib.INSTANCE.Net_EPC1G2_ReadLabelID(handler.getValue(), (byte) 1, 0, (byte) 0, new byte[]{}, buff, count);
        if (ret != 0) {
            return null;
        }
        byte wordCount = buff[0];
        byte[] epc = new byte[wordCount * 2];
        System.arraycopy(buff, 1, epc, 0, wordCount * 2);
        return epc;
    }

    public static String bytes2HexString(byte[] b, int count) {
        String ret = "";
        for (int i = 0; i < count; i++) {
            String hex = Integer.toHexString(b[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            ret += hex.toUpperCase() + " ";
        }
        return ret;
    }
    public static VF447Client getVF447Client(String ip, short port){
        VF447Client client = new VF447Client();
        int ret = client.Net_ConnectScanner(ip, (short)1969, "172.20.2.110", port);
        if (ret != 0) {
            System.err.println("connect to reader fail" + ret);
            return null;
        }
        return client;
    }
    public static void main(String[] args) throws InterruptedException {
        List<VF447Client> clients = new ArrayList<>();
        /**
         * 23，22为无法连接的安全门
         * 20，21为可连接的安全门
         * 该代码不变的情况下，20的安全门无法读取，且rfid也不会被安全门读取（经过时不会出现滴的一声）
         * 21的安全门无影响
         */
        VF447Client client3 = getVF447Client("172.20.2.23", (short)15559);
        if(client3 != null){
            clients.add(client3);
        }
        VF447Client client = getVF447Client("172.20.2.20", (short)13556);
        if(client != null){
            clients.add(client);
        }
        VF447Client client2 = getVF447Client("172.20.2.22", (short)15558);
        if(client2 != null){
            clients.add(client2);
        }
        VF447Client client1 = getVF447Client("172.20.2.21", (short)65557);
        if(client1 != null){
            clients.add(client1);
        }

        while(true) {
            for (VF447Client item : clients) {
                byte[] epc = item.readEPC();
                if (epc != null) {
                    System.out.println("epc: " + bytes2HexString(epc, epc.length));
                }
                Thread.sleep(100);
            }
        }
    }
}
